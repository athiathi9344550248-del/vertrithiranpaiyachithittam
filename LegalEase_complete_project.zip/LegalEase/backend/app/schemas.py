from typing import List

from pydantic import BaseModel, Field, field_validator


class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=120)
    parties: str = Field(..., min_length=2, max_length=4000)
    terms: List[str] = Field(default_factory=list, max_length=50)
    effective_date: str = Field(..., min_length=2, max_length=80)
    jurisdiction: str = Field(default="", max_length=200)
    governing_law: str = Field(default="", max_length=300)
    additional_notes: str = Field(default="", max_length=5000)

    @field_validator("document_type", "parties", "effective_date")
    @classmethod
    def strip_required(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Field cannot be empty.")
        return value

    @field_validator("terms")
    @classmethod
    def clean_terms(cls, value: List[str]) -> List[str]:
        return [item.strip() for item in value if item and item.strip()]


class ExportRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=120)
    content: str = Field(..., min_length=1, max_length=100000)
    company_name: str = Field(default="LegalEase", max_length=200)

    @field_validator("content")
    @classmethod
    def strip_content(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Document content cannot be empty.")
        return value


class GenerateResponse(BaseModel):
    document_type: str
    content: str
    model: str
