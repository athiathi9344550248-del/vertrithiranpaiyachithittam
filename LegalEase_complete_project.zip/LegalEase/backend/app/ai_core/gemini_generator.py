from google import genai
from google.genai import types

from backend.app.config import Settings
from backend.app.schemas import DocumentRequest
from backend.app.utils.text_utils import sanitize_text


class GeminiDocumentGenerator:
    """Testable wrapper around Google's current GenAI SDK."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._client = None

    @property
    def client(self):
        if self._client is None:
            if not self.settings.gemini_api_key:
                raise RuntimeError(
                    "GEMINI_API_KEY is not configured. Add it to the .env file."
                )
            self._client = genai.Client(api_key=self.settings.gemini_api_key)
        return self._client

    def build_prompt(self, request: DocumentRequest) -> str:
        terms = "\n".join(
            f"- {term}" for term in request.terms
        ) or "- No specific terms supplied."
        jurisdiction = request.jurisdiction or "Not specified"
        governing_law = request.governing_law or "Not specified"
        notes = request.additional_notes or "None"

        return f"""
Draft a professional legal document based strictly on the supplied facts.

DOCUMENT TYPE:
{request.document_type}

PARTIES:
{request.parties}

EFFECTIVE DATE:
{request.effective_date}

JURISDICTION:
{jurisdiction}

GOVERNING LAW:
{governing_law}

REQUESTED TERMS:
{terms}

ADDITIONAL NOTES:
{notes}

Requirements:
1. Produce a complete, editable draft with a clear title and logical numbered sections.
2. Include placeholders such as [INSERT ADDRESS] only where material information is missing.
3. Do not invent names, dates, monetary amounts, addresses, statutes, case citations, registration numbers, or other facts.
4. Preserve the supplied business terms faithfully.
5. Use neutral professional legal drafting language.
6. Include signature blocks appropriate to the parties.
7. Add a short "Drafting Notice" at the end stating that the document should be reviewed for jurisdiction-specific requirements.
8. Do not claim the document is legally valid, guaranteed, attorney-reviewed, or legally sound.
9. Return only the document draft; do not surround it with Markdown code fences.
""".strip()

    def generate_document(self, request: DocumentRequest) -> str:
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=self.build_prompt(request),
            config=types.GenerateContentConfig(
                temperature=0.25,
                max_output_tokens=12000,
                system_instruction=(
                    "You are a careful legal-document drafting assistant. "
                    "You generate drafts, not legal advice. Never invent facts."
                ),
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned no text. Please try again.")
        return sanitize_text(text)
