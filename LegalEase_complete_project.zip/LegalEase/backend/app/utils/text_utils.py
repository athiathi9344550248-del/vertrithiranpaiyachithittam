import re
import unicodedata
from html import escape


def sanitize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "-")
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def ascii_for_pdf(text: str) -> str:
    replacements = {
        "“": '"', "”": '"', "‘": "'", "’": "'",
        "–": "-", "—": "-", "•": "-", "…": "...",
        "©": "(c)", "®": "(R)", "™": "(TM)",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    normalized = unicodedata.normalize("NFKD", text)
    return normalized.encode("ascii", "ignore").decode("ascii")


def html_preview(text: str) -> str:
    blocks = []
    for block in re.split(r"\n\s*\n", sanitize_text(text)):
        safe = escape(block).replace("\n", "<br>")
        if re.match(r"^(ARTICLE|SECTION|[0-9]+\.|[A-Z][A-Z\s&-]{3,})", block.strip()):
            blocks.append(f"<h3>{safe}</h3>")
        else:
            blocks.append(f"<p>{safe}</p>")
    return "".join(blocks)
