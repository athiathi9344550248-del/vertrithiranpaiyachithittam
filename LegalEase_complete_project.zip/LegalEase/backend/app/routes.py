from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

from backend.app.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.app.config import get_settings
from backend.app.schemas import DocumentRequest, ExportRequest, GenerateResponse
from backend.app.services.document_service import DocumentService

router = APIRouter()
settings = get_settings()
generator = GeminiDocumentGenerator(settings)


@router.get("/")
def root():
    return {"service": settings.app_name, "status": "running", "docs": "/docs"}


@router.get("/health")
def health():
    return {"status": "ok", "service": settings.app_name}


@router.post("/generate", response_model=GenerateResponse)
def generate(request: DocumentRequest):
    try:
        content = generator.generate_document(request)
        return GenerateResponse(
            document_type=request.document_type,
            content=content,
            model=settings.gemini_model,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Document generation failed: {exc}") from exc


@router.post("/export/txt")
def export_txt(request: ExportRequest):
    return Response(
        content=DocumentService.as_txt(request.content),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{_safe_filename(request.document_type)}.txt"'},
    )


@router.post("/export/docx")
def export_docx(request: ExportRequest):
    data = DocumentService.as_docx(request.document_type, request.content, request.company_name)
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f'attachment; filename="{_safe_filename(request.document_type)}.docx"'},
    )


@router.post("/export/pdf")
def export_pdf(request: ExportRequest):
    data = DocumentService.as_pdf(request.document_type, request.content, request.company_name)
    return Response(
        content=data,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{_safe_filename(request.document_type)}.pdf"'},
    )


def _safe_filename(value: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in value)
    return "_".join(safe.strip().split())[:80] or "legalease_document"
