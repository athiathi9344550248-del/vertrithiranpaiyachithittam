from io import BytesIO
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

from backend.app.utils.text_utils import ascii_for_pdf, sanitize_text


ASSET_LOGO = Path(__file__).resolve().parents[3] / "assets" / "logo.png"


class LegalPDF(FPDF):
    def __init__(self, title: str, company_name: str):
        super().__init__()
        self.title_text = title
        self.company_name = company_name
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        if ASSET_LOGO.exists():
            self.image(str(ASSET_LOGO), x=10, y=8, w=22)
            self.set_xy(36, 10)
        else:
            self.set_xy(10, 10)
        self.set_font("Helvetica", "B", 12)
        self.cell(0, 8, ascii_for_pdf(self.company_name), ln=1)
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(
            0, 8,
            f"{ascii_for_pdf(self.company_name)} | Drafting tool - verify before use",
            align="C",
        )


class DocumentService:
    @staticmethod
    def as_txt(content: str) -> bytes:
        return sanitize_text(content).encode("utf-8")

    @staticmethod
    def as_docx(document_type: str, content: str, company_name: str = "LegalEase") -> bytes:
        doc = Document()
        section = doc.sections[0]
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(0.7)
        section.left_margin = Inches(0.85)
        section.right_margin = Inches(0.85)

        normal = doc.styles["Normal"]
        normal.font.name = "Times New Roman"
        normal.font.size = Pt(11)

        if ASSET_LOGO.exists():
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(str(ASSET_LOGO), width=Inches(1.0))

        title = doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run(document_type.upper())
        run.bold = True
        run.font.name = "Times New Roman"
        run.font.size = Pt(15)

        brand = doc.add_paragraph()
        brand.alignment = WD_ALIGN_PARAGRAPH.CENTER
        brand.add_run(company_name).italic = True

        for block in sanitize_text(content).split("\n\n"):
            block = block.strip()
            if not block:
                continue
            if len(block) < 90 and (
                block.upper() == block
                or block.startswith("ARTICLE ")
                or block.startswith("SECTION ")
            ):
                p = doc.add_paragraph()
                r = p.add_run(block)
                r.bold = True
                r.font.name = "Times New Roman"
                r.font.size = Pt(12)
            else:
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(6)
                p.paragraph_format.line_spacing = 1.08
                p.add_run(block)

        footer = section.footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer.add_run(
            f"{company_name} | AI-assisted draft | Review for applicable law before use"
        )
        footer_run.font.size = Pt(8)

        buffer = BytesIO()
        doc.save(buffer)
        return buffer.getvalue()

    @staticmethod
    def as_pdf(document_type: str, content: str, company_name: str = "LegalEase") -> bytes:
        pdf = LegalPDF(document_type, company_name)
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.multi_cell(0, 9, ascii_for_pdf(document_type), align="C")
        pdf.ln(5)

        for block in sanitize_text(content).split("\n\n"):
            block = block.strip()
            if not block:
                continue
            is_heading = (
                len(block) < 90
                and (
                    block.upper() == block
                    or block.startswith("ARTICLE ")
                    or block.startswith("SECTION ")
                )
            )
            pdf.set_font("Helvetica", "B" if is_heading else "", 11 if is_heading else 10)
            pdf.multi_cell(0, 5.5, ascii_for_pdf(block))
            pdf.ln(2)

        return bytes(pdf.output())
