from functools import lru_cache
import os

from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()


class Settings(BaseModel):
    app_name: str = Field(default="LegalEase")
    gemini_api_key: str = Field(default="")
    gemini_model: str = Field(default="gemini-3.8-flash")
    backend_url: str = Field(default="http://127.0.0.1:8000")
    max_document_chars: int = Field(default=50000)


@lru_cache
def get_settings() -> Settings:
    return Settings(
        app_name=os.getenv("APP_NAME", "LegalEase"),
        gemini_api_key=os.getenv("GEMINI_API_KEY", ""),
        gemini_model=os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
        backend_url=os.getenv("BACKEND_URL", "http://127.0.0.1:8000"),
        max_document_chars=int(os.getenv("MAX_DOCUMENT_CHARS", "50000")),
    )
