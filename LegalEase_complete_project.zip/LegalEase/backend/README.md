Backend package. Run from project root with `uvicorn backend.app.main:app --reload --port 8000`.
