from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["service"] == "LegalEase"


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_generate_validation():
    response = client.post("/generate", json={
        "document_type": "",
        "parties": "A",
        "terms": [],
        "effective_date": "2026-09-29",
    })
    assert response.status_code == 422
