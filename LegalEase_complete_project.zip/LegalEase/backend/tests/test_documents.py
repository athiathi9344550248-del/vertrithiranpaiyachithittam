from backend.app.services.document_service import DocumentService

SAMPLE = """GENERAL AGREEMENT

1. PARTIES

This Agreement is between Party A and Party B.

2. TERMS

Payment is due within 30 days.

3. SIGNATURES

Party A: ____________________

Party B: ____________________
"""


def test_txt_export():
    data = DocumentService.as_txt(SAMPLE)
    assert b"GENERAL AGREEMENT" in data


def test_docx_export():
    data = DocumentService.as_docx("General Agreement", SAMPLE)
    assert data[:2] == b"PK"


def test_pdf_export():
    data = DocumentService.as_pdf("General Agreement", SAMPLE)
    assert data.startswith(b"%PDF")
