import os

import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .hero {
        padding: 1.4rem 1.6rem;
        border-radius: 16px;
        background: linear-gradient(135deg, #0f2747 0%, #2457a6 100%);
        color: white;
        margin-bottom: 1.2rem;
    }
    .hero h1 { margin: 0; font-size: 2.2rem; }
    .hero p { margin: .45rem 0 0; opacity: .9; }
    .notice {
        padding: .85rem 1rem;
        border-left: 4px solid #d9a441;
        background: #fff8e7;
        border-radius: 8px;
        color: #4b3b13;
    }
    .preview {
        background: #101722;
        color: #eef3f8;
        border-radius: 12px;
        padding: 1.2rem 1.35rem;
        max-height: 620px;
        overflow-y: auto;
        line-height: 1.65;
    }
    .preview p { margin-bottom: 1rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
      <h1>⚖️ LegalEase</h1>
      <p>AI-assisted legal document drafting, editing, and export.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="notice"><strong>Drafting notice:</strong> LegalEase generates editable drafts, not legal advice. Verify facts and have important documents reviewed by a qualified legal professional.</div>',
    unsafe_allow_html=True,
)
st.write("")

if "document" not in st.session_state:
    st.session_state.document = ""
if "document_type" not in st.session_state:
    st.session_state.document_type = ""

with st.sidebar:
    st.header("Document details")
    document_type = st.selectbox(
        "Document type",
        [
            "Employment Contract",
            "Non-Disclosure Agreement",
            "Lease Agreement",
            "Employment Offer Letter",
            "Freelance Work Contract",
            "Service Agreement",
            "General Agreement",
            "Other",
        ],
    )
    if document_type == "Other":
        document_type = st.text_input("Custom document type", "General Agreement")

    parties = st.text_area(
        "Parties and roles",
        placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=100,
    )
    terms_raw = st.text_area(
        "Terms & conditions",
        placeholder="Payment due within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice",
        height=160,
        help="Separate each term with a semicolon.",
    )
    effective_date = st.text_input("Effective date", placeholder="September 29, 2026")
    jurisdiction = st.text_input("Jurisdiction (optional)", placeholder="Tamil Nadu, India")
    governing_law = st.text_input("Governing law (optional)", placeholder="Applicable Indian law")
    company_name = st.text_input("Brand/company name", "LegalEase")
    additional_notes = st.text_area("Additional notes (optional)", height=100)

    generate = st.button("✨ Generate Document", type="primary", use_container_width=True)

if generate:
    if not parties.strip() or not effective_date.strip():
        st.error("Please provide the parties and effective date.")
    else:
        terms = [t.strip() for t in terms_raw.split(";") if t.strip()]
        payload = {
            "document_type": document_type.strip(),
            "parties": parties.strip(),
            "terms": terms,
            "effective_date": effective_date.strip(),
            "jurisdiction": jurisdiction.strip(),
            "governing_law": governing_law.strip(),
            "additional_notes": additional_notes.strip(),
        }
        try:
            with st.spinner("Generating your editable draft..."):
                response = requests.post(f"{BACKEND_URL}/generate", json=payload, timeout=180)
            if response.ok:
                result = response.json()
                st.session_state.document = result["content"]
                st.session_state.document_type = result["document_type"]
                st.success(f"Generated with {result.get('model', 'configured Gemini model')}.")
            else:
                detail = response.json().get("detail", response.text)
                st.error(f"Backend error: {detail}")
        except requests.RequestException as exc:
            st.error("Could not reach the FastAPI backend. Make sure it is running on BACKEND_URL.")
            st.caption(str(exc))

if st.session_state.document:
    st.subheader("Document preview")
    tab_preview, tab_edit = st.tabs(["Preview", "Edit"])

    with tab_preview:
        from backend.app.utils.text_utils import html_preview
        st.markdown(
            f'<div class="preview">{html_preview(st.session_state.document)}</div>',
            unsafe_allow_html=True,
        )

    with tab_edit:
        edited = st.text_area(
            "Edit the generated document",
            value=st.session_state.document,
            height=600,
            key="editable_document",
        )
        if st.button("Save edits to current document"):
            st.session_state.document = edited
            st.success("Edits saved for export.")

    st.divider()
    st.subheader("Download")

    export_payload = {
        "document_type": st.session_state.document_type or document_type,
        "content": st.session_state.document,
        "company_name": company_name or "LegalEase",
    }

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Prepare TXT", use_container_width=True):
            try:
                r = requests.post(f"{BACKEND_URL}/export/txt", json=export_payload, timeout=30)
                r.raise_for_status()
                st.session_state.txt_bytes = r.content
            except requests.RequestException as exc:
                st.error(f"TXT export failed: {exc}")
        if "txt_bytes" in st.session_state:
            st.download_button(
                "⬇️ Download TXT",
                data=st.session_state.txt_bytes,
                file_name="legalease_document.txt",
                mime="text/plain",
                use_container_width=True,
            )

    with col2:
        if st.button("Prepare DOCX", use_container_width=True):
            try:
                r = requests.post(f"{BACKEND_URL}/export/docx", json=export_payload, timeout=30)
                r.raise_for_status()
                st.session_state.docx_bytes = r.content
            except requests.RequestException as exc:
                st.error(f"DOCX export failed: {exc}")
        if "docx_bytes" in st.session_state:
            st.download_button(
                "⬇️ Download DOCX",
                data=st.session_state.docx_bytes,
                file_name="legalease_document.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                use_container_width=True,
            )

    with col3:
        if st.button("Prepare PDF", use_container_width=True):
            try:
                r = requests.post(f"{BACKEND_URL}/export/pdf", json=export_payload, timeout=30)
                r.raise_for_status()
                st.session_state.pdf_bytes = r.content
            except requests.RequestException as exc:
                st.error(f"PDF export failed: {exc}")
        if "pdf_bytes" in st.session_state:
            st.download_button(
                "⬇️ Download PDF",
                data=st.session_state.pdf_bytes,
                file_name="legalease_document.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
else:
    st.info("Fill in the fields in the sidebar and click Generate Document to begin.")
