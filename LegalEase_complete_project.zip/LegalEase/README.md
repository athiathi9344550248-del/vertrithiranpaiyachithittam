# LegalEase — AI-Powered Legal Document Generator

LegalEase is a Streamlit + FastAPI application that uses Google's Gemini API to draft editable legal-document text from structured user inputs and export the result as TXT, DOCX, or PDF.

> **Important:** LegalEase is a drafting/education tool, not a lawyer or law firm. Generated content can contain errors and may not be appropriate for a particular jurisdiction or transaction. Have important documents reviewed by a qualified legal professional.

## Architecture

```text
Streamlit frontend
      |
      | HTTP / JSON
      v
FastAPI backend
      |
      +---- GeminiDocumentGenerator ---- Google Gemini API
      |
      +---- DocumentService ------------ TXT / DOCX / PDF
```

The original project documentation called for Gemini 1.5 Pro and the legacy `google-generativeai` package. This implementation uses Google's current `google-genai` SDK and keeps the model in an environment variable so it can be changed without editing code.

## Project tree

```text
LegalEase/
├── assets/
│   └── logo.png
├── backend/
│   ├── app/
│   │   ├── ai_core/
│   │   │   └── gemini_generator.py
│   │   ├── services/
│   │   │   └── document_service.py
│   │   ├── utils/
│   │   │   └── text_utils.py
│   │   ├── config.py
│   │   ├── main.py
│   │   ├── routes.py
│   │   └── schemas.py
│   ├── tests/
│   │   ├── test_api.py
│   │   └── test_documents.py
│   └── __init__.py
├── frontend/
│   └── app.py
├── .env.example
├── .gitignore
├── .streamlit/config.toml
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.10+
- A Gemini API key
- VS Code recommended
- Internet access for Gemini generation

## Local setup

### 1. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows CMD:

```cmd
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and add your API key:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
BACKEND_URL=http://127.0.0.1:8000
```

If your API account does not expose the default model, change `GEMINI_MODEL` to another currently available text-generation model in your Gemini account.

### 4. Start the FastAPI backend

From the project root:

```bash
uvicorn backend.app.main:app --reload --host 127.0.0.1 --port 8000
```

Health check:

```text
http://127.0.0.1:8000/health
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

### 5. Start Streamlit

Open a second terminal, activate the same virtual environment, then:

```bash
streamlit run frontend/app.py
```

Open the URL Streamlit prints, normally:

```text
http://localhost:8501
```

## How to use

1. Select or enter a document type.
2. Enter parties and roles.
3. Enter terms separated by semicolons.
4. Enter the effective date.
5. Optionally add jurisdiction, governing law, company name, and notes.
6. Click **Generate Document**.
7. Edit the generated text in the editor.
8. Download TXT, DOCX, or PDF.

## API

### `GET /`

Returns service metadata.

### `GET /health`

Returns `{"status":"ok","service":"LegalEase API"}`.

### `POST /generate`

Example request:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
  "terms": [
    "Confidential information must be protected",
    "Use is limited to evaluating the business relationship",
    "Either party may terminate on 15 days notice"
  ],
  "effective_date": "2026-09-29",
  "jurisdiction": "Tamil Nadu, India",
  "governing_law": "Applicable Indian law",
  "additional_notes": ""
}
```

### Export endpoints

- `POST /export/txt`
- `POST /export/docx`
- `POST /export/pdf`

They accept `document_type`, `content`, and optional `company_name`.

## Testing

Run:

```bash
pytest -q
```

The tests cover API health/validation and TXT/DOCX/PDF rendering. The Gemini API itself is not called by the test suite.

## Docker

```bash
docker compose up --build
```

The UI is on port 8501 and the API is on port 8000.

## Production notes

Before public deployment, add authentication, rate limiting, request logging with redaction, encrypted storage if documents are persisted, a secrets manager, HTTPS, and a privacy/data-retention policy. Do not log API keys or sensitive document contents.

## Source basis

The supplied documentation specifies Streamlit, FastAPI, Gemini, editable preview, and TXT/DOCX/PDF export. This implementation preserves those requirements while updating the obsolete Gemini SDK choice.
